# CNKI Metadata Exporter

一个可复用的知网检索结果元数据导出工具。它使用 Playwright 打开知网专业检索，按独立检索集合执行检索，通过知网自定义导出页面分批下载 XLS 元数据，并将多个集合合并、筛选文献类型和去重。

本项目由真实文献数据建设任务中的批量采集流程整理而来，已移除项目检索词、论文元数据、浏览器登录状态和合同专用清洗规则。

## 功能

- 使用 JSON 配置任意数量的 CNKI 专业检索式
- 可选从结构化 DOCX 中提取检索集合
- 自动切换每页 50 条、逐页全选、按批次导出
- 默认每批最多 500 条，已有批次自动续接
- 支持期刊、博士论文、硕士论文及会议论文筛选
- 解析知网自定义导出的 HTML-XLS 文件
- 按 DOI、URL、题名与作者等字段合并去重
- 保留论文命中的检索集合、集合名称和数据层级
- 可选进入详情页补充元数据
- 安全验证出现时停留在可见浏览器中等待用户完成

## 环境

- Python 3.11+
- Chromium
- 能正常访问 CNKI 的个人或机构账号

## 安装

使用 `uv`：

```bash
uv sync --extra dev
uv run playwright install chromium
```

或使用常规 Python：

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e '.[dev]'
playwright install chromium
```

## 1. 准备检索配置

```bash
cp examples/queries.example.json queries.json
```

编辑 `queries.json`：

```json
[
  {
    "id": "Q1",
    "name": "材料主题核心集",
    "field": "SU",
    "query": "SU=('耐磨钢'+'低合金耐磨钢')",
    "purpose": "核心主题论文",
    "tier": "核心材料"
  }
]
```

`id`、`name` 和 `query` 为必填字段。详细格式见 [`docs/query-format.md`](docs/query-format.md)。

## 2. 使用知网原生导出批量获取元数据

这是推荐方式，不需要逐条打开详情页：

```bash
uv run cnki-native-export \
  --queries queries.json \
  --root workspace
```

只运行指定集合：

```bash
uv run cnki-native-export \
  --queries queries.json \
  --root workspace \
  --collection Q1 \
  --batch-size 500
```

首次运行会打开可见浏览器。完成登录后，程序执行专业检索、逐页选择记录，并从知网自定义导出页面下载 XLS。遇到知网安全验证时，在浏览器窗口中完成人工验证即可继续。

运行数据保存在：

```text
workspace/
├── .cnki-profile/             # 浏览器会话，不提交 Git
├── data/queries.resolved.json # 本次实际使用的检索配置快照
├── logs/                      # 运行日志
└── output/native_exports/     # 分集合、分批次的 XLS 和 manifest
```

重新执行相同命令时，已成功下载的批次会被复用。

## 3. 合并、筛选和去重

```bash
uv run cnki-merge-metadata \
  --root workspace \
  --queries queries.json \
  --out workspace/merged
```

默认保留：期刊、博士、硕士、中国会议和国际会议。也可以明确指定：

```bash
uv run cnki-merge-metadata \
  --root workspace \
  --queries queries.json \
  --out workspace/merged \
  --include-database 期刊 \
  --include-database 博士 \
  --include-database 硕士
```

输出包括：

- `raw.json`：筛选文献类型后的全部原始记录
- `unique.json`：跨检索集合合并去重后的记录
- `stats.json`：各集合导出和保留数量
- `queries.json`：实际检索式及用途
- `summary.json`：总体统计

支持的元数据字段见 [`docs/metadata-fields.md`](docs/metadata-fields.md)。

## 4. 可选：逐条详情页采集

当知网原生导出缺少某些字段时，可使用详情模式：

```bash
uv run cnki-metadata-exporter \
  --queries queries.json \
  --root workspace \
  --collection Q1
```

仅抓取结果列表：

```bash
uv run cnki-metadata-exporter \
  --queries queries.json \
  --root workspace \
  --collection Q1 \
  --list-only
```

详情模式速度明显慢于原生导出，适合小规模补充摘要、关键词、机构、基金和 DOI。

## 从 DOCX 读取检索式

DOCX 符合约定的章节和段落结构时，可以使用：

```bash
uv run cnki-native-export \
  --docx search-strategy.docx \
  --root workspace
```

自定义章节标题：

```bash
uv run cnki-native-export \
  --docx search-strategy.docx \
  --docx-start "CNKI检索策略" \
  --docx-end "Web of Science检索策略" \
  --root workspace
```

## 测试

```bash
pytest
ruff check src tests
```

## 数据与账号

`.gitignore` 已排除浏览器会话、Cookie、运行日志、下载文件和采集结果。公开代码仓库中只保留程序、文档和示例配置。使用者应通过自己的合法访问权限使用知网，并遵守账号授权范围和平台规则。

## 页面兼容性

工具针对当前知网 `kns8s` 专业检索与自定义导出页面实现。知网页面结构更新后，主要需要调整 `exporter.py` 和 `native_export.py` 中的页面选择器。

## License

[MIT](LICENSE)

---

**English:** A reusable Playwright-based workflow for running CNKI professional-search queries, exporting native XLS metadata in batches, resuming interrupted jobs, merging collections, filtering publication types, and deduplicating records. See the command examples above and `examples/queries.example.json` to get started.
