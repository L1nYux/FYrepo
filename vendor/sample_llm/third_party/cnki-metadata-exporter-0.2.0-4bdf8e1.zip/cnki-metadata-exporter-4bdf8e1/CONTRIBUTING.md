# Contributing

1. Fork 仓库并创建功能分支。
2. 使用 Python 3.11 或更高版本安装开发依赖：`python -m pip install -e '.[dev]'`。
3. 运行 `pytest` 和 `ruff check src tests`。
4. Pull Request 中说明对应的知网页面、复现步骤和预期行为，但不要上传 Cookie、账号信息或受许可限制的元数据。
