import json
from pathlib import Path

import pytest

from cnki_metadata_exporter.queries import load_queries, validate_queries


def test_load_example_queries() -> None:
    path = Path(__file__).parents[1] / "examples" / "queries.example.json"
    queries = load_queries(path)
    assert [item["id"] for item in queries] == ["Q1", "Q2"]
    assert queries[0]["field"] == "SU"
    assert queries[1]["tier"] == "性能研究"


def test_wrapped_queries_are_supported(tmp_path: Path) -> None:
    path = tmp_path / "queries.json"
    path.write_text(
        json.dumps({"queries": [{"id": "A1", "name": "示例", "query": "SU=('钢')"}]}),
        encoding="utf-8",
    )
    assert load_queries(path)[0]["expression"] == "('钢')"


def test_duplicate_ids_are_rejected() -> None:
    with pytest.raises(ValueError, match="重复"):
        validate_queries(
            [
                {"id": "Q1", "name": "一", "query": "SU=('钢')"},
                {"id": "Q1", "name": "二", "query": "SU=('铁')"},
            ]
        )
